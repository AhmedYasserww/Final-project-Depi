import 'package:flutter/material.dart';
import 'package:kids_education_learning/core/utils/app_color.dart';

class AppStyle {
  //Bold
  static const styleBold14 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 14,
    fontFamily: "Inter",
    fontWeight: FontWeight.w700,
  );
  static const styleBold16 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w700,
  );
  static const styleBoldShopButton16 = TextStyle(
    color: Color(0xFFFFFFFF),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w700,
  );
  static const styleBold18 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 18,
    fontFamily: "Inter",
    fontWeight: FontWeight.w700,
  );
  static const styleBold20 = TextStyle(
    color: Color(0xFF000846),
    fontSize: 20,
    fontFamily: "Inter",
    fontWeight: FontWeight.w700,
  );
  static const styleBold24 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 24,
    fontFamily: "Inter",
    fontWeight: FontWeight.w700,
  );
  static const styleBold32 = TextStyle(
    color: Color(0xFF000846),
    fontSize: 32,
    fontFamily: "Inter",
    fontWeight: FontWeight.w700,
  );
  static const styleBoldShop16 = TextStyle(
    color: Color(0xFF000846),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w700,
  );
  static const styleBold28 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 28,
    fontFamily: "Inter",
    fontWeight: FontWeight.w700,
  );
  static const styleScheduleRegular16 = TextStyle(
    color: Color(0xFF000846),
    fontSize: 16,
    fontWeight: FontWeight.w400
  );

  //////////////////////////////////////////////
  //Semi Bold

  static const styleSemiBold10 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 10,
    fontFamily: "Inter",
    fontWeight: FontWeight.w600,
  );
  static const styleSemiBold12 = TextStyle(
    color: Color(0xFF5D3A82),
    fontSize: 12,
    fontFamily: "Inter",
    fontWeight: FontWeight.w600,
  );
  static const styleSemiBold14 = TextStyle(
    color: Color(0xFF000846),
    fontSize: 14,
    fontFamily: "Inter",
    fontWeight: FontWeight.w600,
  );
  static const styleSemiBold16 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w600,
  );
  static const styleSemiBoldWhite16 = TextStyle(
    color: Color(0xFFFFFFFF),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w600,
    letterSpacing: -.03,
  );
  static const styleSemiBoldGrey16 = TextStyle(
    color: Color(0xFF707070),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w600,
    letterSpacing: -.03,
  );
  static const styleScheduleSemiBold16 = TextStyle(
    color: Color(0xFF343B6E),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w600,
  );
  static const styleScheduleSemiBold17 = TextStyle(
    color: Color(0xFF000846),
    fontSize: 17,
    fontFamily: "Inter",
    fontWeight: FontWeight.w600,
  );
  static const styleSemiBold18 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 18,
    fontFamily: "Inter",
    fontWeight: FontWeight.w600,
  );
  static const styleSemiBold20 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 20,
    fontFamily: "Inter",
    fontWeight: FontWeight.w600,
  );
  static const styleSemiBold22 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 22,
    fontFamily: "Inter",
    fontWeight: FontWeight.w600,
  );
  static const styleSemiBold24 = TextStyle(
    color: Color(0xFF000846),
    fontSize: 24,
    fontFamily: "Inter",
    fontWeight: FontWeight.w600,
  );

  //////////////////////////////////////
  //Medium

  static const styleMedium16 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const styleUploadPhoto16 = TextStyle(
    color: Color(0xFF343B6E),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );

  static const styleMedium12 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 12,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const styleMedium20 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 20,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const styleGreyMedium12 = TextStyle(
    color: Color(0xff666666),
    fontSize: 12,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const styleGreyMedium13 = TextStyle(
    color: Color(0xff666666),
    fontSize: 13,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const styleGreyMedium14 = TextStyle(
    color: Color(0xff666666),
    fontSize: 14,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const styleMedium14 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 14,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const styleScheduleMedium14 = TextStyle(
    color: Color(0xFF000846),
    fontSize: 14,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const styleScheduleMedium17 = TextStyle(
    color: Color(0xFF000846),
    fontSize: 17,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const styleMediumActiveState14 = TextStyle(
    color: Color(0xFF343B6E),
    fontSize: 14,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const styleMediumCompletedState14 = TextStyle(
    color: Color(0xFF343B6E),
    fontSize: 14,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const styleWhiteMedium14 = TextStyle(
    color: Color(0xFF097B09),
    fontSize: 14,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const stylePurpleMedium16 = TextStyle(
    color: Color(0xFF5D3A82),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const stylePurpleMedium20 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 20,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const styleWhiteMedium22 = TextStyle(
    color: Color(0xFFFFFFFF),
    fontSize: 22,
    fontFamily: "Inter",
    fontWeight: FontWeight.w500,
  );
  static const styleChatListView = TextStyle(
    color: Color(0xFF000846),
    fontWeight: FontWeight.w500,
    fontSize: 16,
  );
  //////////////////////////////////////////////////////
  //Regular

  static const styleGreyRegular10 = TextStyle(
    color: Color(0xff666666),
    fontSize: 10,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const styleGreyRegular12 = TextStyle(
    color: Color(0xff666666),
    fontSize: 12,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const styleWhiteRegular10 = TextStyle(
    color: Color(0xFFFFFFFF),
    fontSize: 10,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const styleGreyRegular11 = TextStyle(
    color: Color(0xff666666),
    fontSize: 11,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );

  static const styleRegular12 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 12,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const styleGreyRegular14 = TextStyle(
    color: Color(0xff666666),
    fontSize: 14,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const styleGreyScheduleRegular14 = TextStyle(
    color: Color(0xFF707070),
    fontSize: 14,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const styleRegular14 = TextStyle(
    color: Color(0xFF000846),
    fontSize: 14,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const styleDaysNameRegular14 = TextStyle(
    color: Color(0xFF474747),
    fontSize: 14,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
    letterSpacing: -0.43,
  );
  static const countryStyleTextForm = TextStyle(
    color: Color(0xFF000846),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const styleRegular20 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 20,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const styleRegular18 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 18,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const styleWhiteRegular16 = TextStyle(
    color: Color(0xFFFFFFFF),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w600,
    letterSpacing: -.03,
  );
  static const styleRegular16 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const styleGreyRegular16 = TextStyle(
    color: Color(0xFF707070),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const styleGreyRegularShop14 = TextStyle(
    color: Color(0xFF707070),
    fontSize: 14,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const stylePurpleRegular16 = TextStyle(
    color: Color(0xFF5D3A82),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const stylePurpleRegular18 = TextStyle(
    color: Color(0xFF1A1515),
    fontSize: 18,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const hintStyle = TextStyle(
    color: Color(0xFF707070),
    fontSize: 18,
    fontFamily: "Inter",
    fontWeight: FontWeight.w400,
  );
  static const achievementsStyle = TextStyle(
    color: Color(0xFF707070),
    fontSize: 16,
    fontFamily: "Inter",
    fontWeight: FontWeight.w600,
  );

    static const TextStyle linkTerms = TextStyle(
    fontSize: 14,
    fontWeight: FontWeight.bold,
    decoration: TextDecoration.underline,
    color: AppColors.primaryTextColor,
  );

}
