import 'dart:ui';
abstract class AppColors {
  static const primaryColor = Color(0xFF6671C2);
  static const primaryTextColor = Color(0xFF000846);
  static const secondryTextColor = Color(0xFF343B6E);
  static const selectedTextfieldColor = Color(0xFFEAECFF);
  static const greyTextColor = Color(0xFF666666);
  static const lightPrimaryColor = Color(0xff3F80FF);
  static const palletBorderColor = Color(0xffCFCACA);
  static const cardBorderColor = Color(0xffDFDFDF);
  static const textFieldBorderColor = Color(0xFFF6F6F6);
  static const backGroundColor = Color(0xFFFFFFFF);
  static const labelTextColor = Color(0xFF000846);
  static const borderColor = Color(0xFFCFCACA);
  static const buttonColor = Color(0xFF6671C2);
  static const activeStateColor = Color(0xFFEAEDFF);
  static const completeStateColor = Color(0xFFE6F8E6);
  static const darkBlueColor = Color(0xFF343B6E);
  static const blackColor = Color(0xFF000000);

  static const iconArrowDown = Color(0xFF707070);
  static const switchColor = Color(0x1F787880);
  static const subtitleListTile = Color(0xFF707070);
  static const borderIconFilter = Color(0xFFCFCACA);





}
 