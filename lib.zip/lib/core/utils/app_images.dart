class AppImages {
  static const String logo = 'assets/images/logo.svg';
  static const String avatar = 'assets/images/avatar.png';
  static const String Au = 'assets/images/Au.png';
  static const String facebook = 'assets/images/facebook.png';
  static const String apple = 'assets/images/apple.png';
  static const String google = 'assets/images/google.png';
  static const String checkIcon = 'assets/images/check_icon.svg';
  static const String facebookLogo = 'assets/images/facebook_icon.svg';
  static const String googleLogo = 'assets/images/google_icon.svg';
  static const String profile = 'assets/images/profile.svg';
  static const String searchIcon = 'assets/images/search.svg';
  static const String filterIcon = 'assets/images/filterIcon.svg';
  static const String offerImage = 'assets/images/Offer_1.png';
  static String menImage = 'assets/images/men.png';
  static String bagImage = 'assets/images/bagImage.png';
  static String micImage = 'assets/images/Microphone.svg';
  static String scanImage = 'assets/images/Scan.svg';
  static String vto = 'assets/images/VTO.svg';
  static String checkImage = 'assets/images/check_circle.svg';

  static const String filterIcon1 = 'assets/images/filterIcon_1.svg';
  static const String filterIcon2 = 'assets/images/filterIcon_2.svg';
  static const String productIcon = 'assets/images/ProductIcon.svg';
  static const String whiteProductIcon = 'assets/images/whiteProductIcon.svg';
  static const String blackListIcon = 'assets/images/blackListIcon.svg';
  static const String listIcon = 'assets/images/ListIcon.svg';
  static const String exitIcon = 'assets/images/ExitIcon.svg';
  static const String circleRemove = 'assets/images/circle_remove.svg';
  static const String emptyCart = 'assets/images/empty_cart.svg';
  static const String deleteOutline = 'assets/images/delete-outline.svg';
  static const String editIcon = 'assets/images/icon_edit-thin.svg';
  static const String locationIcon = 'assets/images/location_icon.svg';
  static const String arrowUpIcon = 'assets/images/icon_arrow_up.svg';
  static const String correctIcon = 'assets/images/correct_icon.svg';
  static const String homeOutlined = 'assets/images/home_outlined.svg';
  static const String homeFilled = 'assets/images/home-filled.svg';
  static const String cartOutlined = 'assets/images/cart-outline.svg';
  static const String cartFilled = 'assets/images/cart_filled.svg';
  static const String productOutlined = 'assets/images/product-outlined.svg';
  static const String productFilled = 'assets/images/product-filled.svg';
  static const String info2Image = 'assets/images/info2.svg';
  static const String sellerIcon = 'assets/images/seller_icon.svg';
  static const String notificationIcon = 'assets/images/notification_icon.svg';
  static const String savedAddressIcon = 'assets/images/saved_address_icon.svg';
  static const String groupIcon = 'assets/images/group_icon.svg';
  static const String keyIcon = 'assets/images/key_icon.svg';
  static const String infoImage = 'assets/images/info.svg';
  static const String ordersIcon = 'assets/images/Orders.svg';
  static const String returnsIcon = 'assets/images/Returns.svg';
  static const String wishlistIcon = 'assets/images/Wishlist.svg';
  static const String helpIcon = 'assets/images/Help.svg';
  static const String logoutIcon = 'assets/images/LogOut.svg';


  static const String gmailIcon = 'assets/images/Gmail.svg';
  static const String instagramIcon = 'assets/images/Insita.svg';
  static const String facebookIcon = 'assets/images/FaceBook.svg';
  static const String linkedInIcon = 'assets/images/LinkedIn.svg';
  static const String lightCamera = 'assets/images/light_camera.svg';

  static const String orderConfirmIcon = 'assets/images/correct_icon.svg';
  static const String processingIcon = 'assets/images/Processing.svg';
  static const String deliveredIcon = 'assets/images/DeliveredIcon.svg';
  static const String shippedIcon = 'assets/images/shipped_icon.svg';
  static const String arrivedIcon = 'assets/images/arrived_icon.svg';
  static const String circleAvatar ='assets/images/circle_avatar.svg';


  static const String correctSolidIcon = 'assets/images/solid_success_icon.svg';
  static const String checkDouble = 'assets/images/check-double.svg';
  static const String orderProcessing = 'assets/images/processing_icon.svg';
  static const String orderArrivedIcon = "assets/images/order_arrived_icon.svg";
  static const String orderOutOfDeliveryIcon = "assets/images/order_out_of_delivery.svg";
  static const String orderShippedIcon = "assets/images/order_shipped_icon.svg";

  static const String emptyOrderImage = "assets/images/empty_order.svg";
  static const String emptyReturnImage = "assets/images/empty_return.svg";
  static const String emptyFavoriteImage = "assets/images/empty_favorite.svg";
  static const String bellIcon = "assets/images/bell.svg";
  static const String cloud= "assets/images/cloud.svg";
  static const String cardShapes = "assets/images/card-shapes.svg";
  static const String frame = "assets/images/frame.svg";
  static const String cracterA = "assets/images/A.svg";
  static const String numbers = "assets/images/numbers.svg";
  static const String imageWom = "assets/images/imageWom.png";
  static const String imageMan = "assets/images/imageMan.png";
  static const String country  = "assets/images/country.png";

  static const String homeIcon = "assets/images/home.svg";
  static const String scheduleIcon = "assets/images/calendar.svg";
  static const String lessonIcon = "assets/images/lessons.svg";
  static const String inboxIcon = "assets/images/inbox.svg";
  static const String moreIcon = "assets/images/more.svg";
  static const String profilePic = 'assets/images/prof pic.png';
  static const String iconSearchBar = 'assets/images/prof pic.png';
  static const String profilePhoto = 'assets/images/koala.png';
  static const String vector = 'assets/images/vector.png';
  static const String profileIcon = 'assets/images/profile.svg';


}
