import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kids_education_learning/core/widgets/custom_button.dart';
import 'package:kids_education_learning/feature/bottom_nav_bar/presentation/views/parent_nav_bar_view.dart';
import 'package:kids_education_learning/feature/bottom_nav_bar/presentation/views/teacher_nav_bar_view.dart';

class LetIsGoViewBody extends StatelessWidget {
  const LetIsGoViewBody({super.key, required this.isTeacher});

  final bool isTeacher;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(color: const Color(0xFFEBEBEB)),
        SizedBox.expand(
          child: SvgPicture.asset(
            "assets/images/Background.svg",
            fit: BoxFit.cover,
          ),
        ),
        Center(
          child: SvgPicture.asset("assets/images/title.svg"),
        ),
        SafeArea(
          child: Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(left: 16, right: 16, bottom: 24),
              child: CustomButton(
                text: "Let's go",
                onTap: () {
                  Navigator.of(context).pushNamedAndRemoveUntil(
                    isTeacher
                        ? TeacherNavBarView.routeName
                        : ParentNavBarView.routeName,
                        (route) => false,
                  );
                },
              ),
            ),
          ),
        ),
      ],
    );
  }
}