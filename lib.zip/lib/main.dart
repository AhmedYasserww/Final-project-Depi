// import 'package:device_preview/device_preview.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:kids_education_learning/feature/parent_auth/presentation/views/schedul_view.dart';
import 'package:kids_education_learning/feature/parent_auth/presentation/views/teacher_schedule_view.dart';
import 'package:kids_education_learning/feature/splash/presentations/views/splash_view.dart';
import 'core/helper_functions/on_generate_routes.dart';
import 'core/service_locator/service_locator.dart';
import 'feature/achievements/presentations/views/lesson1_view.dart';
import 'feature/achievements/presentations/views/lessons_match_view.dart';
import 'feature/bottom_nav_bar/presentation/views/bottom_nav_bar_view.dart';
import 'feature/parent_auth/presentation/views/create_account_view.dart';
import 'feature/parent_auth/presentation/views/log_in_view.dart';
import 'feature/parent_auth/presentation/views/profile_parent_view.dart';
import 'feature/parent_auth/presentation/views/widgets/create_account_view_body.dart';
import 'feature/parent_auth/presentation/views/widgets/teacher_details_view_body.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  setupServiceLocator();
  runApp(
    // DevicePreview(
    //   enabled: !kReleaseMode,
    //   builder: (context) => MyApp(),
    // ),
    MyApp(),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      //  useInheritedMediaQuery: true,
      // locale: DevicePreview.locale(context),
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.white,
        fontFamily: 'Inter',
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFFFFFFFF),
          elevation: 0,
        ),
      ),

      onGenerateRoute: onGenerateRoutes,
      initialRoute: SplashScreen.routeName,
      // onGenerateRoute: onGenerateRoutes,
      // initialRoute: CreateAccountView.routeName,
    );
  }
}
